var valorAnoLuz = 10; /* Aqui será o valor em ano luz para chegar em um planeta distante */

var valorUmAnoLuz = 9460080000000.0; /* Aqui será o valor do ano luz reduzido em metros */

var valorEmMetros =
  valorAnoLuz *
  valorUmAnoLuz; /* O valor do ano luz será multiplicado pela quantidade de metros que deve chegar em um planeta distante */

valorEmMetros = valorEmMetros.toFixed(
  2
); /* Pegaremos o valor completo até o segundo valor após a vírgula */

alert(
  "O valor de " + valorAnoLuz + " anos luz é " + valorEmMetros
); /* Será mostrado no alert a descrição a cima */
